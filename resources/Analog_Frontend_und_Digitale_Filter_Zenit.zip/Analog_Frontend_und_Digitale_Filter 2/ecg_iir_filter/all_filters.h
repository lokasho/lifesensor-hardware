#ifndef ALL_FILTERS_H_INCLUDED
#define ALL_FILTERS_H_INCLUDED

float apply_ecg_filtering(float ecg_sample);

#endif // ALL_FILTERS_H_INCLUDED
