#ifndef CONSTANTS_H_INCLUDED
#define CONSTANTS_H_INCLUDED
//sample rate
#define Fs  250.0
//sample time
#define Ts  1/250.0

#endif
